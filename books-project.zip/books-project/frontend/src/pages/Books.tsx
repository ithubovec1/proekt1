import { FormEvent, useEffect, useState } from 'react';
import { useBookStore, Book } from '../store/bookStore';

const emptyForm = {
  title: '',
  author: '',
  year: '',
  genre: '',
  description: ''
};

const genreColors: Record<string, string> = {
  'Роман': 'bg-pink-100 text-pink-700',
  'Фантастика': 'bg-purple-100 text-purple-700',
  'Детектив': 'bg-amber-100 text-amber-700',
  'Поэзия': 'bg-rose-100 text-rose-700',
  'Научное': 'bg-teal-100 text-teal-700',
  'Классика': 'bg-emerald-100 text-emerald-700'
};

export default function Books() {
  const { books, loading, fetchBooks, addBook, updateBook, deleteBook } =
    useBookStore();
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleChange = (field: string, value: string) => {
    setForm({ ...form, [field]: value });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.title || !form.author || !form.year) {
      setError('Заполните название, автора и год');
      return;
    }

    const data = {
      title: form.title,
      author: form.author,
      year: Number(form.year),
      genre: form.genre,
      description: form.description
    };

    try {
      if (editingId) {
        await updateBook(editingId, data);
      } else {
        await addBook(data);
      }
      setForm(emptyForm);
      setEditingId(null);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Ошибка сохранения');
    }
  };

  const handleEdit = (book: Book) => {
    setEditingId(book.id);
    setForm({
      title: book.title,
      author: book.author,
      year: String(book.year),
      genre: book.genre,
      description: book.description
    });
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Удалить книгу?')) return;
    await deleteBook(id);
  };

  return (
    <div className="max-w-5xl mx-auto p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded-2xl shadow-lg mb-6 border-t-4 border-blue-600"
      >
        <h2 className="font-bold text-xl mb-4 text-gray-800">
          {editingId ? '✏️ Редактировать книгу' : '➕ Добавить книгу'}
        </h2>

        {error && (
          <p className="text-red-500 text-sm mb-3 bg-red-50 border border-red-200 p-2 rounded-lg">
            {error}
          </p>
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          <input
            placeholder="Название"
            value={form.title}
            onChange={(e) => handleChange('title', e.target.value)}
            className="border border-gray-300 p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
          />
          <input
            placeholder="Автор"
            value={form.author}
            onChange={(e) => handleChange('author', e.target.value)}
            className="border border-gray-300 p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
          />
          <input
            placeholder="Год"
            type="number"
            value={form.year}
            onChange={(e) => handleChange('year', e.target.value)}
            className="border border-gray-300 p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
          />
          <input
            placeholder="Жанр"
            value={form.genre}
            onChange={(e) => handleChange('genre', e.target.value)}
            className="border border-gray-300 p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
          />
        </div>

        <textarea
          placeholder="Описание"
          value={form.description}
          onChange={(e) => handleChange('description', e.target.value)}
          className="w-full border border-gray-300 p-3 rounded-lg mt-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
          rows={3}
        />

        <div className="flex gap-2 mt-4">
          <button className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition shadow-md font-medium">
            {editingId ? 'Сохранить' : 'Добавить'}
          </button>
          {editingId && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setForm(emptyForm);
              }}
              className="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition"
            >
              Отмена
            </button>
          )}
        </div>
      </form>

      <h2 className="font-bold text-xl mb-4 text-gray-800">📖 Мои книги</h2>

      {loading && (
        <p className="text-gray-500 text-center py-8">Загрузка...</p>
      )}
      {!loading && books.length === 0 && (
        <div className="bg-white p-8 rounded-2xl shadow text-center text-gray-500">
          Книг пока нет. Добавьте первую!
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        {books.map((book) => {
          const colorClass =
            genreColors[book.genre] || 'bg-blue-100 text-blue-700';
          return (
            <div
              key={book.id}
              className="bg-white rounded-2xl shadow-md border-l-4 border-blue-500 hover:shadow-xl hover:-translate-y-1 transition overflow-hidden"
            >
              <div className="p-5">
                <h3 className="font-bold text-lg text-gray-800">
                  {book.title}
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  {book.author}, {book.year}
                </p>
                {book.genre && (
                  <span
                    className={`inline-block mt-2 text-xs px-3 py-1 rounded-full font-medium ${colorClass}`}
                  >
                    {book.genre}
                  </span>
                )}
                {book.description && (
                  <p className="text-sm mt-3 text-gray-600">
                    {book.description}
                  </p>
                )}
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => handleEdit(book)}
                    className="bg-amber-500 text-white px-4 py-1.5 rounded-lg hover:bg-amber-600 transition text-sm shadow-sm"
                  >
                    Изменить
                  </button>
                  <button
                    onClick={() => handleDelete(book.id)}
                    className="bg-red-500 text-white px-4 py-1.5 rounded-lg hover:bg-red-600 transition text-sm shadow-sm"
                  >
                    Удалить
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}