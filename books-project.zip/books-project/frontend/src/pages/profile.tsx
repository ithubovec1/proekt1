import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useBookStore } from '../store/bookStore';

export default function Profile() {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const books = useBookStore((s) => s.books);
  const fetchBooks = useBookStore((s) => s.fetchBooks);
  const navigate = useNavigate();

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) return null;

  const letter = user.email[0].toUpperCase();

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-blue-600 text-center">
        <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center text-4xl font-bold mb-4 shadow-lg">
          {letter}
        </div>

        <h1 className="text-2xl font-bold text-gray-800">{user.email}</h1>
        <p className="text-sm text-gray-500 mt-1">Читатель BookShelf</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-5 rounded-xl shadow-md">
            <p className="text-sm opacity-90 mb-1">Книг в каталоге</p>
            <p className="text-4xl font-bold">{books.length}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-pink-500 text-white p-5 rounded-xl shadow-md">
            <p className="text-sm opacity-90 mb-1">Статус</p>
            <p className="text-4xl font-bold">📖</p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="mt-8 bg-red-500 text-white px-8 py-3 rounded-lg hover:bg-red-600 transition shadow-md font-medium"
        >
          Выйти из аккаунта
        </button>
      </div>

      <p className="text-center text-xs text-gray-500 mt-6">
        © BookShelf — личный каталог книг
      </p>
    </div>
  );
}