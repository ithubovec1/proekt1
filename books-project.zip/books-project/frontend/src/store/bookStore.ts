import { create } from 'zustand';
import api from '../api/axios';

export type Book = {
  id: number;
  title: string;
  author: string;
  year: number;
  genre: string;
  description: string;
};

type BookState = {
  books: Book[];
  loading: boolean;
  fetchBooks: () => Promise<void>;
  addBook: (data: Omit<Book, 'id'>) => Promise<void>;
  updateBook: (id: number, data: Omit<Book, 'id'>) => Promise<void>;
  deleteBook: (id: number) => Promise<void>;
};

export const useBookStore = create<BookState>((set, get) => ({
  books: [],
  loading: false,
  fetchBooks: async () => {
    set({ loading: true });
    const res = await api.get('/books');
    set({ books: res.data, loading: false });
  },
  addBook: async (data) => {
    const res = await api.post('/books', data);
    set({ books: [res.data, ...get().books] });
  },
  updateBook: async (id, data) => {
    const res = await api.put('/books/' + id, data);
    set({
      books: get().books.map((b) => (b.id === id ? res.data : b))
    });
  },
  deleteBook: async (id) => {
    await api.delete('/books/' + id);
    set({ books: get().books.filter((b) => b.id !== id) });
  }
}));