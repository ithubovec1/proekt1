import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';

export default function Navbar() {
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-gradient-to-r from-blue-700 to-indigo-700 shadow-lg">
      <div className="max-w-5xl mx-auto p-4 flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/books"
          className="text-xl font-bold text-white hover:text-blue-100 transition"
        >
          📚 BookShelf
        </Link>

        <div className="flex items-center gap-1">
          <Link
            to="/books"
            className="text-sm text-white hover:bg-white/20 px-3 py-2 rounded-lg transition"
          >
            Мои книги
          </Link>
          <Link
            to="/profile"
            className="text-sm text-white hover:bg-white/20 px-3 py-2 rounded-lg transition"
          >
            Профиль
          </Link>
          <button
            onClick={handleLogout}
            className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition shadow-sm ml-2"
          >
            Выйти
          </button>
        </div>
      </div>
    </nav>
  );
}