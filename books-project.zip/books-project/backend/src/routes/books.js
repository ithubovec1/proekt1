const express = require('express');
const prisma = require('../prisma');
const auth = require('../middleware/auth');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  const books = await prisma.book.findMany({
    where: { userId: req.userId },
    orderBy: { id: 'desc' }
  });
  res.json(books);
});

router.get('/:id', auth, async (req, res) => {
  const id = Number(req.params.id);
  const book = await prisma.book.findFirst({
    where: { id, userId: req.userId }
  });

  if (!book) {
    return res.status(404).json({ message: 'Книга не найдена' });
  }

  res.json(book);
});

router.post('/', auth, async (req, res) => {
  const { title, author, year, genre, description } = req.body;

  if (!title || !author || !year) {
    return res.status(400).json({ message: 'Заполните обязательные поля' });
  }

  const book = await prisma.book.create({
    data: {
      title,
      author,
      year: Number(year),
      genre: genre || '',
      description: description || '',
      userId: req.userId
    }
  });

  res.status(201).json(book);
});

router.put('/:id', auth, async (req, res) => {
  const id = Number(req.params.id);
  const { title, author, year, genre, description } = req.body;

  const existing = await prisma.book.findFirst({
    where: { id, userId: req.userId }
  });

  if (!existing) {
    return res.status(404).json({ message: 'Книга не найдена' });
  }

  const book = await prisma.book.update({
    where: { id },
    data: {
      title,
      author,
      year: Number(year),
      genre,
      description
    }
  });

  res.json(book);
});

router.delete('/:id', auth, async (req, res) => {
  const id = Number(req.params.id);

  const existing = await prisma.book.findFirst({
    where: { id, userId: req.userId }
  });

  if (!existing) {
    return res.status(404).json({ message: 'Книга не найдена' });
  }

  await prisma.book.delete({ where: { id } });
  res.json({ message: 'Удалено' });
});

module.exports = router;